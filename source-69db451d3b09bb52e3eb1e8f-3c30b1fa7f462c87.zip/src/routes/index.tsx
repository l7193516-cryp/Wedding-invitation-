import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'

export const Route = createFileRoute('/')({
  component: WeddingInvitation,
})

const pages = [
  { id: 'invocation', src: '/page-invocation.png' },
  { id: 'couple', src: '/page-couple.png' },
  { id: 'functions', src: '/page-functions.png' },
  { id: 'savethedate', src: '/page-savethedate.png' },
]

function WeddingInvitation() {
  const [currentPage, setCurrentPage] = useState(0)
  const [flipping, setFlipping] = useState(false)
  const [direction, setDirection] = useState<'next' | 'prev'>('next')

  const goTo = (next: number) => {
    if (flipping || next === currentPage) return
    setDirection(next > currentPage ? 'next' : 'prev')
    setFlipping(true)
    setTimeout(() => {
      setCurrentPage(next)
      setFlipping(false)
    }, 600)
  }

  const goNext = () => { if (currentPage < pages.length - 1) goTo(currentPage + 1) }
  const goPrev = () => { if (currentPage > 0) goTo(currentPage - 1) }

  return (
    <div className="wedding-root" onClick={goNext}>
      <div className={`book-wrapper ${flipping ? `flip-${direction}` : ''}`}>
        <div className="page-content">
          {pages.map((page, i) => (
            currentPage === i && (
              <div key={page.id} className="page-image-wrapper fade-in">
                {page.id === 'couple' ? (
                  <div className="couple-page-container">
                    <img src={page.src} alt={page.id} className="page-image" />
                    <div className="date-correction">APRIL</div>
                  </div>
                ) : (
                  <img src={page.src} alt={page.id} className="page-image" />
                )}
              </div>
            )
          ))}
        </div>

        <div className="page-nav" onClick={(e) => e.stopPropagation()}>
          <button className="nav-btn" onClick={goPrev} disabled={currentPage === 0}>&#8249;</button>
          <div className="page-dots">
            {pages.map((_, i) => (
              <span key={i} className={`dot ${i === currentPage ? 'active' : ''}`} onClick={() => goTo(i)} />
            ))}
          </div>
          <button className="nav-btn" onClick={goNext} disabled={currentPage === pages.length - 1}>&#8250;</button>
        </div>

        <p className="tap-hint" onClick={(e) => e.stopPropagation()}>
          {currentPage < pages.length - 1 ? 'Tap anywhere to continue \u2192' : '\u2190 Tap \u2039 to go back'}
        </p>
      </div>
    </div>
  )
}
